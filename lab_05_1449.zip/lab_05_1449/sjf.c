#include<stdio.h>

struct process{
     int arrival_time;
     int brust_time;
     int completion_time;
     int turnaround_time;
     int waiting_time;
     int processed;
};

void sjf(struct process processes[], int n){
     int total_time =0, track[n];
     double avgWait=0, avgTurn=0;
     for (int i = 0; i < n; i++) {
        track[i] = i;
    }
     for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(processes[j].brust_time > processes[j+1].brust_time){
               struct process temp = processes[j];
               processes[j] = processes[j+1];
               processes[j+1] = temp;
               int tempIndex = track[j];
                track[j] = track[j + 1];
                track[j + 1] = tempIndex;
            }
        }
        
     }
     printf("Gantt chat:\n");
     printf("|");
     for(int i=0; i<n; i++){
         printf("--P%d--|", track[i]+1);
     }
     printf("\n");
     
     for(int i=0; i<n; i++){
        if(total_time < processes[i].arrival_time){
           total_time = processes[i].arrival_time;
        }
        processes[i].completion_time = total_time + processes[i].brust_time;
        processes[i].turnaround_time = processes[i].completion_time - processes[i].arrival_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].brust_time;
        total_time = processes[i].completion_time;
        avgWait = avgWait + processes[i].waiting_time;
        avgTurn = avgTurn + processes[i].turnaround_time;
        
     }
     printf("0");
     for(int i=0; i<n; i++){
         printf("      %d", processes[i].completion_time);
     }
     
     printf("\n");
     avgWait /= n;
     avgTurn /= n;


    printf("Process\tTurnaround Time\tWaiting Time\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t\t%d\t\t%d\n", i,processes[i].turnaround_time, processes[i].waiting_time);
    }
    printf("\nAverage Turnaround Time: %.2lf\nAverage Waiting Time: %.2lf\n", avgTurn, avgWait);

}


int main(void){
    struct process processes[] = {{0, 2}, {0, 1},{0, 8},{0,4},{0, 5}};
    int n = sizeof(processes)/sizeof(processes[0]);
    sjf(processes, n);
    return 0;
}
