#include<stdio.h>

struct Process{
     char id;
     int burst_time;
     int priority;
     int arrival_time;
     int completion_time;
     int turnaround_time;
     int waiting_time;
     int processed;
};

void psnp(struct Process processes[], int n) {
    int total_time = 0;
    float average_turnaround_time = 0, average_waiting_time = 0;

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (processes[j].priority < processes[j + 1].priority) {
                struct Process temp = processes[j];
                processes[j] = processes[j + 1];
                processes[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < n; i++) {
        if (total_time < processes[i].arrival_time) {
            total_time = processes[i].arrival_time;
        }
        total_time += processes[i].burst_time;
        processes[i].completion_time = total_time;
        processes[i].turnaround_time = processes[i].completion_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].burst_time;
        average_turnaround_time += processes[i].turnaround_time;
        average_waiting_time += processes[i].waiting_time;
    }

    average_turnaround_time /= n;
    average_waiting_time /= n;

    printf("Gantt Chart:\n");
    printf("-----------\n");
    for (int i = 0; i < n; i++) {
        printf("|  P%d  ", processes[i].id - '0');
    }
    printf("|\n");

    printf("\nProcess | Turnaround Time | Waiting Time\n");
    for (int i = 0; i < n; i++) {
        printf("   P%d   |      %d     |    %d     | \n", processes[i].id - '0', processes[i].turnaround_time, processes[i].waiting_time);
    }
    printf("\nAverage Turnaround Time: %.2f\nAverage Waiting Time: %.2f\n", average_turnaround_time, average_waiting_time);
}



int main(void){
    struct Process processes[] = { {'1', 2, 2, 0}, {'2', 1, 1, 0}, {'3', 8, 4, 0}, {'4', 4, 2, 0}, {'5', 5, 3, 0} };
    //struct Process processes[] = {{'1',20, 40, 0},{'2',25, 30, 25},{'3', 25, 30, 30},{'4',15,35,60},{'5',10, 5, 100},{'6', 10, 10, 105}};
    int n = sizeof(processes)/sizeof(processes[0]);
    psnp(processes, n);
    return 0;
}
