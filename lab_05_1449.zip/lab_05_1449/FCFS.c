#include<stdio.h>
#include<stdlib.h>

struct Process {
    int arrival_time;
    int burst_time;
};

void calculateTimes(struct Process processes[], int n, int waiting_time[], int turnaround_time[]) {
    waiting_time[0] = 0;
    turnaround_time[0] = processes[0].burst_time;

    for (int i = 1; i < n; i++) {
        waiting_time[i] = waiting_time[i - 1] + processes[i - 1].burst_time;
        turnaround_time[i] = waiting_time[i] + processes[i].burst_time;
    }
}

int main(){
    
    struct Process processes[] = { {0, 2}, {0, 1}, {0, 8}, {0, 4}, {0, 5}};
    int n = sizeof(processes) / sizeof(processes[0]);

    int waiting_time[n], turnaround_time[n];

    calculateTimes(processes, n, waiting_time, turnaround_time);
    
    printf("Gantt Chat:\n");
    printf("|");
    for(int i=1; i<=n; i++){
       printf("--P%d--|", i);       
    }
    printf("\n");
    printf("0  ");
    for(int i=0; i<n; i++){
       printf("    %d  ",turnaround_time[i]);       
    }
    printf("\n");
    double avgWait=0, avgTurn=0;

    printf("Process\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        avgWait = avgWait+waiting_time[i];
        avgTurn = avgTurn+turnaround_time[i];
        printf("%d\t%d\t\t%d\n", i, waiting_time[i], turnaround_time[i]);
    }
    avgWait = avgWait/n;
    avgTurn = avgTurn/n;
    printf("Avg Waiting Time = %lf\n", avgWait);
    printf("Avg Turn Around Time = %lf\n", avgTurn);
    
    
    
    return 0;
}
