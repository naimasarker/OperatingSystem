#include<stdio.h>
#include<stdlib.h>

struct Process {
    int arrival_time;
    int burst_time;
    int remaining_time;
};

void calculateTimes(struct Process processes[], int n, int quantum, int waiting_time[], int turnaround_time[]) {
    int remaining_burst_time[n];
    int time[12], t=1;
    for (int i = 0; i < n; i++) {
        remaining_burst_time[i] = processes[i].burst_time;
        processes[i].remaining_time = processes[i].burst_time;
    }

    int current_time = 0;
    printf("Gantt chat:\n");
    printf("|");
    while (1) {
        int done = 1;
        for (int i = 0; i < n; i++) {
            if (remaining_burst_time[i] > 0) {
                done = 0;
                if (remaining_burst_time[i] > quantum) {
                    current_time += quantum;
                    remaining_burst_time[i] -= quantum;
                    printf("---P%d---|", i+1);
                    //printf("\n  %d  ", current_time);
                    time[t] = current_time;
                    t++;
                } else {
                    current_time += remaining_burst_time[i];
                    waiting_time[i] = current_time - processes[i].burst_time;
                    remaining_burst_time[i] = 0;
                    turnaround_time[i] = current_time - processes[i].arrival_time;
                    printf("---P%d---|", i+1);
                    //printf("\n  %d  ", current_time);
                    time[t] = current_time;
                    t++;
                }
            }
            
        }
        if (done == 1) break;
    }
    printf("\n");
    printf("0");
    for(int i=1; i<t;  i++){
        //printf("  %d    ", time[i]);
        printf("--------%d", time[i]);
    }
    printf("\n");
    
}

int main() {
    struct Process processes[] = { {0, 2}, {0, 1}, {0, 8}, {0, 4}, {0, 5}};
    int n = sizeof(processes) / sizeof(processes[0]);
    
    int quantum;
    printf("Enter the quantam time: ");
    scanf("%d", &quantum);
    int waiting_time[n], turnaround_time[n];
    calculateTimes(processes, n, quantum, waiting_time, turnaround_time);
   
    double avgWait=0, avgTurn=0;
    printf("Process\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        avgWait = avgWait+waiting_time[i];
        avgTurn = avgTurn+turnaround_time[i];
        printf("%d\t%d\t\t%d\n", i, waiting_time[i], turnaround_time[i]);
    }
    
    avgWait = avgWait/n;
    avgTurn = avgTurn/n;
    printf("Avg Waiting Time = %lf\n", avgWait);
    printf("Avg Turn Around Time = %lf\n", avgTurn);

    return 0;
}
